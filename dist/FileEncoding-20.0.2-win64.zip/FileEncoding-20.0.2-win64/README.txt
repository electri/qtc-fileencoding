﻿文件编码插件 FileEncoding
适用于 Qt Creator 20.0.2（Windows x64，MSVC 2022 构建版）
================================================================

作用
----
在「工具 → 文件编码」菜单里直接切换默认文本编码，不必打开「首选项 → 文本编辑器」：

    UTF-8
    GBK

切换后会把已经打开的文件按新编码重新读入。带 BOM 的文件仍然以 BOM 为准。

安装
----
1. 关闭 Qt Creator（运行中的进程会锁住插件 DLL）。
2. 把本压缩包里的 lib 目录合并到 Qt Creator 安装目录，例如
       C:\Qt\Tools\QtCreator-20.0.2\
   合并后应当存在：
       C:\Qt\Tools\QtCreator-20.0.2\lib\qtcreator\plugins\FileEncoding.dll
3. 重新启动 Qt Creator。
4. 菜单「工具 → 文件编码」下会出现两个可勾选项，勾选状态与当前默认编码一致。

卸载
----
删除 <安装目录>\lib\qtcreator\plugins\FileEncoding.dll 即可。
插件不写其它文件，卸载后不留残余设置。

环境要求
--------
* Qt Creator 20.0.2 x64，且必须是 MSVC 2022 构建的版本。插件与宿主共享
  C++ ABI，不能跨编译器或跨大版本（21.x）使用。
* 依赖的 TextEditor.dll、Core.dll、Utils.dll、ExtensionSystem.dll 以及
  Qt6 运行库都由 Qt Creator 自带，无需另外安装，也不需要 Qt SDK。
* GBK 支持依赖 Qt 的 ICU 模块（Qt Creator 官方构建已启用）。若运行环境缺少
  ICU，插件会在切换时给出提示，不会崩溃。

使用时的行为
------------
* 存在未保存修改的文档时会弹窗确认：全部重新打开 / 跳过已修改 / 取消。
  重新读入会丢弃这些未保存内容，但该操作本身可以撤销。
* 新建且从未保存过的文件没有磁盘字节可读，只会改变它之后保存时使用的编码。
* 状态栏右下角的编码标签会在重开后自动刷新。
* 菜单勾选状态跟随「首选项」里的默认编码设置，两边改动互相同步。

许可证
------
GPL-3.0-only WITH Qt-GPL-exception-1.0，完整文本见 LICENSE.txt。
源代码：https://github.com/electri/qtc-fileencoding

校验
----
SHA-256 见同目录 SHA256.txt。

构建信息
--------
源：Qt Creator 20.0.2 源码树 src/plugins/fileencoding
Qt：6.11.2 msvc2022_64
编译器：MSVC 14.44 (Visual Studio 2022)
